<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SkyHouston Online Car Sales</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
		body{
			background-color: ;
		}
	</style>
</head>
<body>

	<div class="container">
		
		<div class = "navbar">

				<div class= "logo1">
					<img src="images/logos.jpg" width = "125px">
					
				</div>

				<nav>
					
					<ul>
						<li><a href="">Home</a></li>
						
						<li><a href="add_buyer.php">Register</a></li>
						<li><a href="login.php">Login</a></li>
						
					</ul>
				</nav>
			</div>

			<div class = "row">
				<div class = "col-2">
					<h1>SkyHouston Online<br> Car Sales</h1>
			<p>We are a new platform into the car sales platform<br>that aims at meeting our customers nessds and<br> future expectations.<br>A happy client is a happy vender</p>
				</div>
						

				

				
				<div class="col-2">
					<img src="images/logos.jpg" width="1000">
				</div>

			</div>
		</div>	



<!--featured section-->

	<div class="categories">
		<h2>Featured Models</h2>
		<br>

		<div class="row">
			<div class="col-3">
				<img src="images/trucks.jpg" width="200">
				<p><b><center>trucks</center></b></p>
			</div>

			<div class="col-3">
				<img src="images/suvs.jpg" width="200">
				<p><b><center>suvs</center></b></p>
			</div>

			<div class="col-3">
				<img src="images/lorries.jpg" width="200">
				<p><b><center>lorries</center></b></p>
			</div>

			<div class="col-3">
				<img src="images/buses.jpg" width="200">
				<p><b><center>buses</center></b></p>
			</div>

			<div class="col-3">
				<img src="images/minis.png" width="200">
				<p><b><center>coupes</center></b></p>
			</div>
				
			
			
		</div>

	</div>	
<br>
<br>


<!--footer-->

	<footer class="footer">
		<div class="inner-footer">
			

			<div class="quick-links">
				<ul>
					<li class="quick-items"><a href="">About us</a></li>
					<li class="quick-items"><a href="">Privacy Policy</a></li>
					<li class="quick-items"><a href="">Contacts</a></li>

				</ul>
				

			</div>
			

		</div>
		
		<div class="outer-footer">
			 SkyHouston Online Car Sales. All rights reserved. Copyright &copy;2021
			
		</div>

	</footer>


</body>
</html>
# Web-based-Vehicle-sales-system

This is a simple vehicle selling and purchasing system completed in Php, javascript , html and css

# Requirements
A Xampp or Wampp or any other server of your choice and youre good to go.

